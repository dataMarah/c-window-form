﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void toolStripComboBox1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

            Application.Exit();
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (pictureBox1 != null)
            {
                SaveFileDialog sv = new SaveFileDialog();
                sv.Filter = "GIF|* .gif|PNG|* .png|JPEG|* .jpeg";
                sv.FileName = "NewImage";
                if (sv.ShowDialog() == DialogResult.OK)
                {
                    pictureBox1.Image.Save(sv.FileName);
                }
            }
            else
                MessageBox.Show("Pleas insert an image");
        }

        private void goPage2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 1;
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("ID : 165881 \r\n Name : Marah");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            double x1 = double.Parse(TextBox1.Text);
            double y1 = double.Parse(TextBox2.Text);
            double x2 = double.Parse(TextBox3.Text);
            double y2 = double.Parse(TextBox4.Text);
            double distance = Math.Sqrt(Math.Pow(x2 - x1, 2) + Math.Pow(y2 - y1, 2));

            button4.Text = distance.ToString("F2");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            double x1 = double.Parse(TextBox1.Text);
            double Y1 = double.Parse(TextBox2.Text);
            double X2 = double.Parse(TextBox3.Text);
            double Y2 = double.Parse(TextBox4.Text);
            double midX = (x1 + X2) / 2;
            double midY = (Y1 + Y2) / 2;
            button5.Text = $"({midX:F2}, {midY:F2})";
            
        }

        private void priToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (TextBox1.Text =="" || TextBox2.Text == "" || TextBox3.Text == "" || TextBox4.Text == "")
            {

                MessageBox.Show("Missing value!");
            }


            else if (TextBox1.Text.Any(char.IsLetter) || TextBox2.Text.Any(char.IsLetter) || TextBox3.Text.Any(char.IsLetter) || TextBox4.Text.Any(char.IsLetter))
            {
                MessageBox.Show("Incorrect Format!");
            }

            TextBox5.Text = "Point 1 = (" + TextBox1.Text + ", " + TextBox2.Text + ") \r\n" +
                                         "Point 2 = (" + TextBox3.Text + ", " + TextBox4.Text + ")";

            // Enable the buttons
            button1.Enabled = true;
            button2.Enabled = true;
            button3.Enabled = true;


        }
        private void groupBox2_Enter(object sender, EventArgs e)
        {
            
        }

        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TextBox1.Clear();
            TextBox2.Clear();
            TextBox3.Clear();
            TextBox4.Clear();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            double x1 = double.Parse(TextBox1.Text);
            double y1 = double.Parse(TextBox2.Text);
            double x2 = double.Parse(TextBox4.Text);
            double y2 = double.Parse(TextBox3.Text);

            
            if (x2 == x1)
            {

                pictureBox1.Image = Properties.Resources.verticalImage;
                TextBox5.Text = "The line is vertical.";
                return;
            }
            double slope = (y2 - y1) / (x2 - x1);
            button6.Text = slope.ToString("F2");

            if (slope > 0)
            {
                pictureBox1.Image = Properties.Resources.positivrImage;
                TextBox5.Text = "Right side of the line is higher than the left side.";
            }
            else if (slope < 0)
            {
                pictureBox1.Image = Properties.Resources.negativeImage;
                TextBox5.Text = "Line goes down and right .";
            }
            else if (y2 == y1)
            {
                pictureBox1.Image = Properties.Resources.horizontalImage;
                TextBox5.Text = "The line is horizontal.";
            }
        }

        

        private void button1_Click(object sender, EventArgs e)
        {

            double x1, y1, x2, y2;

            bool ok =
                double.TryParse(TextBox1.Text, out x1) &&
                double.TryParse(TextBox2.Text, out y1) &&
                double.TryParse(TextBox3.Text, out x2) &&
                double.TryParse(TextBox4.Text, out y2);

            if (!ok)
            {
                MessageBox.Show("Incorrect Format!");
                return;
            }

            button4.Enabled = true;
            button5.Enabled = true;
            button6.Enabled = true;

            TextBox5.Text = "Start points is : (" + TextBox1.Text + ", " + TextBox2.Text + ")" +
            "\r\nEnd points is: (" + TextBox4.Text + ", " + TextBox3.Text + ")" +
            "\r\n Distance betweean the two points :"+ button4.Text +
            "\r\n Mid point:"+button5.Text +
            "\r\n The Slope is : " +button6.Text;

            tabControl1.SelectedTab = tabPage3;
        }

        

        

        private void button2_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage1;
        }



        private void button7_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage2;
        }

        private void goPage2ToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 1;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            TextBox5.Font = new Font(TextBox5.Font.FontFamily, TextBox5.Font.Size, FontStyle.Bold ^ TextBox5.Font.Style);
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            TextBox5.Font = new Font(TextBox5.Font.FontFamily, TextBox5.Font.Size, FontStyle.Italic ^ TextBox5.Font.Style);

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void TextBox5_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
